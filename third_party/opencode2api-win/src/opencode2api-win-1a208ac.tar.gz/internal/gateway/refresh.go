package gateway

import (
	"context"
	"errors"
	"net/http"
	"sync"
	"time"

	"opencode2api/internal/config"
	modelcatalog "opencode2api/internal/models"
)

const (
	// The probe answers "can this exit serve traffic?", so it targets the
	// OpenCode origin itself. cloudflare.com is an unrelated third party that
	// proxy providers routinely block or rate-limit on their egress, so exits
	// that serve OpenCode fine were disabled and eventually retired by a probe
	// that never touched OpenCode. checkClaimedProxy counts any HTTP response
	// as success, so a 404 from the origin still proves the tunnel reaches it.
	proxyHealthCheckURL      = "https://opencode.ai/"
	proxyHealthCheckInterval = 15 * time.Minute
	proxyHealthCheckTimeout  = 10 * time.Second
)

// syncProxyResult updates proxy health from real traffic and reports whether
// it treated the outcome as a proxy-route failure; nil and #pool proxies are
// skipped and report false. Only timeouts and connection refusals mark a
// proxy unavailable: its keys are rebound elsewhere at once and a confirming
// health check starts in the background. Any upstream HTTP status (including
// one returned alongside a status error) proves the proxy route is reachable
// and restores a proxy evicted by an earlier transient failure. Errors without
// an HTTP response only start the background check, which never affects the
// return value.
func (g *Gateway) syncProxyResult(ctx context.Context, proxy *proxyTransport, status int, err error) bool {
	if proxy == nil || proxy.pool {
		return false
	}
	if status > 0 {
		wasHealthy := proxy.healthy.Swap(true)
		if !wasHealthy {
			g.restoreProxy(proxy)
		}
		return false
	}
	if isProxyFailure(err) {
		g.rebindFailedProxy(proxy)
		g.verifyProxyAfterError(ctx, proxy, "proxy transport error", status)
		return true
	}
	if err != nil {
		g.verifyProxyAfterError(ctx, proxy, "upstream request error", status)
		return false
	}
	return false
}

// verifyProxyAfterError starts a background health check of proxy, unless one
// is already in flight, and applies its result. source and status only label
// the log; the source distinguishes a missing HTTP response from another
// upstream request error.
func (g *Gateway) verifyProxyAfterError(ctx context.Context, proxy *proxyTransport, source string, status int) {
	if !proxy.checking.CompareAndSwap(false, true) {
		return
	}
	// The client request may finish or be canceled while the verification is
	// running. Keep its values but give the proxy check an independent timeout.
	checkCtx := context.WithoutCancel(ctx)
	go func() {
		result := g.transports.checkClaimedProxy(checkCtx, proxy, proxyHealthCheckURL, proxyHealthCheckTimeout)
		g.applyProxyHealthResult(result, source, status)
	}()
}

// rebindFailedProxy marks proxy unhealthy and moves the Zen and Go keys bound
// to it to other proxies (see rebindUnavailableProxy).
func (g *Gateway) rebindFailedProxy(proxy *proxyTransport) (zenMoved, goMoved int) {
	if proxy == nil {
		return 0, 0
	}
	wasHealthy := proxy.healthy.Swap(false)
	return g.rebindUnavailableProxy(proxy, wasHealthy)
}

// rebindUnavailableProxy moves the Zen and Go keys bound to proxy to other
// proxies and logs the eviction when the proxy was healthy before or any key
// moved. It does not touch the healthy flag, and anonymous nodes are never
// rebound.
func (g *Gateway) rebindUnavailableProxy(proxy *proxyTransport, wasHealthy bool) (zenMoved, goMoved int) {
	zenMoved = g.zenNodes.RebindProxy(proxy.index)
	goMoved = g.goNodes.RebindProxy(proxy.index)
	if wasHealthy || zenMoved+goMoved > 0 {
		g.logger.Warn("proxy became unavailable", "component", "proxy", "event", "proxy_unavailable", "proxy", config.RedactURL(proxy.name), "zen_keys_moved", zenMoved, "go_keys_moved", goMoved)
	}
	return zenMoved, goMoved
}

// restoreProxy moves keys back to a recovered proxy they were originally
// assigned to and clears the anonymous cooldowns bound to it. It does not set
// the healthy flag; callers do that first.
func (g *Gateway) restoreProxy(proxy *proxyTransport) (zenMoved, goMoved int) {
	if proxy == nil {
		return 0, 0
	}
	zenMoved = g.zenNodes.RestoreProxy(proxy.index)
	goMoved = g.goNodes.RestoreProxy(proxy.index)
	// The anonymous lane carries its own per-proxy cooldowns; key recovery
	// alone would leave it skipped after an outage-era failure.
	anonCleared := g.anonymous.RestoreProxy(proxy)
	if zenMoved+goMoved > 0 || anonCleared > 0 {
		g.logger.Info("proxy connectivity restored", "component", "proxy", "event", "proxy_restored", "proxy", config.RedactURL(proxy.name), "zen_keys_moved", zenMoved, "go_keys_moved", goMoved, "anonymous_cleared", anonCleared)
	}
	return zenMoved, goMoved
}

// StartProxyHealthChecks rechecks unhealthy proxies every
// proxyHealthCheckInterval until ctx is canceled. There is no check at
// startup, since every proxy starts healthy.
func (g *Gateway) StartProxyHealthChecks(ctx context.Context) {
	check := func() {
		results := g.transports.CheckHealth(ctx, proxyHealthCheckURL, proxyHealthCheckTimeout)
		for _, result := range results {
			g.applyProxyHealthResult(result, "scheduled health check", 0)
		}
	}
	go func() {
		ticker := time.NewTicker(proxyHealthCheckInterval)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				check()
			}
		}
	}()
}

// applyProxyHealthResult acts on one health check: a pass restores a proxy
// that was unhealthy, a proxy-route failure rebinds its keys only while some
// proxy is still healthy, and an inconclusive error changes nothing. source
// and upstreamStatus only label the log.
func (g *Gateway) applyProxyHealthResult(result proxyHealthResult, source string, upstreamStatus int) {
	if result.err == nil {
		if !result.wasHealthy {
			g.restoreProxy(result.proxy)
		}
		g.logger.Debug("proxy health check passed", "component", "proxy", "event", "health_check_passed", "source", source, "upstream_status", upstreamStatus, "proxy", config.RedactURL(result.proxy.name))
		return
	}
	if !result.failed {
		g.logger.Debug("proxy health check was inconclusive", "component", "proxy", "event", "health_check_inconclusive", "source", source, "upstream_status", upstreamStatus, "proxy", config.RedactURL(result.proxy.name), "error", result.err)
		return
	}
	if g.transports.hasHealthy() {
		zenMoved, goMoved := g.rebindUnavailableProxy(result.proxy, result.wasHealthy)
		if result.wasHealthy || zenMoved+goMoved > 0 {
			g.logger.Warn("proxy health check failed", "component", "proxy", "event", "health_check_failed", "source", source, "upstream_status", upstreamStatus, "proxy", config.RedactURL(result.proxy.name), "zen_keys_moved", zenMoved, "go_keys_moved", goMoved, "error", result.err)
			return
		}
	}
	g.logger.Debug("proxy health check is still failing", "component", "proxy", "event", "health_check_still_failing", "source", source, "upstream_status", upstreamStatus, "proxy", config.RedactURL(result.proxy.name), "error", result.err)
}

// RefreshCatalog refreshes the catalog once. Concurrent or overlapping executions
// on this gateway are skipped via g.refreshMu.
func (g *Gateway) RefreshCatalog(ctx context.Context) {
	if !g.refreshMu.TryLock() {
		return
	}
	defer g.refreshMu.Unlock()
	var zen, goModels []string
	var capabilities modelcatalog.Capabilities
	var capabilitiesErr error
	var wg sync.WaitGroup
	wg.Add(3)
	go func() {
		defer wg.Done()
		if g.cfg.ZenOAuth == nil {
			zen = g.refreshZen(ctx)
		}
	}()
	go func() {
		defer wg.Done()
		if g.cfg.GoOAuth == nil {
			goModels = g.refreshTier(ctx, g.cfg.Upstream.Go, g.goNodes)
		}
	}()
	go func() {
		defer wg.Done()
		capabilityCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
		defer cancel()
		capabilities, capabilitiesErr = g.refreshProtocolCapabilities(capabilityCtx)
	}()
	wg.Wait()
	if ctx.Err() != nil {
		return
	}
	if capabilitiesErr != nil {
		g.logger.Warn("OpenCode capability catalog refresh failed", "component", "models", "event", "capability_refresh_failed", "error", capabilitiesErr)
	}
	if g.cfg.GoOAuth != nil {
		goModels = g.seedOAuthCatalog(&capabilities, config.TierGo)
	}
	if g.cfg.ZenOAuth != nil {
		zen = g.seedOAuthCatalog(&capabilities, config.TierZen)
	}
	if zen != nil || goModels != nil {
		g.catalog.ReplaceWithCapabilities(zen, goModels, capabilities.Protocols, capabilities.Unsupported, capabilities.Metadata, g.oauthTiers()...)
		g.syncRotation()
		if ctx.Err() == nil {
			if err := g.catalog.SaveCache(); err != nil {
				g.logger.Warn("model catalog cache write failed", "component", "models", "event", "catalog_cache_write_failed", "error", err)
			}
		}
		g.logger.Info("model catalog refreshed", "component", "models", "event", "catalog_refreshed", "models", len(g.catalog.List()))
	}
}

// StartModelRefresh refreshes the model catalog at once and then every
// models.refresh_seconds until ctx is canceled. Each round concurrently lists
// the Zen models (through the anonymous lane when no Zen key can) and the Go
// models, and fetches OpenCode's protocol capabilities. The catalog is
// replaced only when at least one listing succeeded; the rotation groups are
// then resynced and the catalog cache saved. If a refresh fails, the last-known-good
// catalog is preserved intact.
// Overlapping refresh executions within this gateway are skipped via g.refreshMu.
func (g *Gateway) StartModelRefresh(ctx context.Context) {
	go func() {
		g.RefreshCatalog(ctx)
		ticker := time.NewTicker(time.Duration(g.cfg.Models.RefreshSeconds) * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				g.RefreshCatalog(ctx)
			}
		}
	}()
}

// refreshProtocolCapabilities fetches OpenCode's capability catalog through
// each healthy proxy in turn until one succeeds. Only a gateway without any
// transport falls back to a direct client.
func (g *Gateway) refreshProtocolCapabilities(ctx context.Context) (modelcatalog.Capabilities, error) {
	if g.transports == nil || len(g.transports.items) == 0 {
		return modelcatalog.FetchCapabilities(ctx, &http.Client{Timeout: 30 * time.Second}, modelcatalog.CapabilitiesURL)
	}
	var lastErr error
	for _, proxy := range g.transports.items {
		if proxy == nil || !proxy.healthy.Load() {
			continue
		}
		capabilities, err := modelcatalog.FetchCapabilities(ctx, proxy.client, modelcatalog.CapabilitiesURL)
		if err == nil {
			return capabilities, nil
		}
		lastErr = err
	}
	if lastErr == nil {
		lastErr = errors.New("no healthy proxy available for OpenCode capability catalog")
	}
	return modelcatalog.Capabilities{}, lastErr
}

// refreshZen lists the Zen models with the Zen keys and, when that fails and
// the anonymous tier is enabled, with the public credential instead.
func (g *Gateway) refreshZen(ctx context.Context) []string {
	if models := g.refreshTier(ctx, g.cfg.Upstream.Zen, g.zenNodes); models != nil {
		return models
	}
	if !g.cfg.Anonymous {
		return nil
	}
	return g.refreshAnonymousTier(ctx, g.cfg.Upstream.Anonymous)
}

// refreshAnonymousTier lists models with the public credential, one anonymous
// node per attempt: one pass over the nodes, or up to retry.max_attempts
// attempts when #pool transports exist. base only labels the logs.
func (g *Gateway) refreshAnonymousTier(ctx context.Context, base string) []string {
	if !g.anonymous.AllowAttempt() {
		// The breaker is open, or its half-open probe is already running:
		// refreshing now would only add to the block. Keeping nil leaves the
		// previous catalog in place.
		g.logger.Debug("anonymous model catalog refresh skipped; circuit breaker is not closed", "component", "models", "event", "anonymous_refresh_paused", "upstream", config.RedactURL(base))
		return nil
	}
	defer g.anonymous.ReleaseProbe()
	if g.warp != nil {
		return g.refreshAnonymousWARP(ctx, base)
	}
	cursor := g.anonymous.CursorFor("")
	limit := min(g.anonymous.Len(), g.maxAnonymousExits())
	if g.anonymous.HasPool() && g.cfg.Retry.MaxAttempts > limit {
		limit = g.cfg.Retry.MaxAttempts
	}
	for attempt := 1; attempt <= limit; attempt++ {
		node := cursor.Next()
		if node == nil {
			break
		}
		refreshCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
		var models []string
		var status int
		var err error
		// List models on the configured v2 /inference origin; the v1 fallback
		// is retired (see anonymousUpstreams).
		for _, upstream := range g.anonymousUpstreams() {
			models, status, err = modelcatalog.FetchModels(refreshCtx, node.proxy.client, upstream, anonymousZenKey)
			if err == nil || isProxyFailure(err) {
				break
			}
		}
		g.syncProxyResult(refreshCtx, node.proxy, status, err)
		cancel()
		if err == nil {
			g.anonymous.MarkSuccess(node)
			g.anonymous.NoteSuccess()
			return models
		}
		g.anonymous.MarkFailure(node, nil, err)
		g.logger.Debug("anonymous model catalog refresh attempt failed", "component", "models", "event", "anonymous_refresh_attempt_failed", "upstream", config.RedactURL(base), "attempt", attempt, "proxy", config.RedactURL(node.proxy.name), "error", err)
	}
	g.logger.Warn("anonymous model catalog refresh failed", "component", "models", "event", "anonymous_refresh_failed", "upstream", config.RedactURL(base))
	return nil
}

// refreshAnonymousWARP lists models through WARP instead of an anonymous
// proxy. The catalog is what makes free models discoverable at all, so with
// the WARP switch on it must not depend on a working proxy pool. One lease per
// attempt; the pool learns about a blocked exit through Report.
func (g *Gateway) refreshAnonymousWARP(ctx context.Context, base string) []string {
	limit := max(g.cfg.Retry.MaxAttempts, 1)
	for attempt := 1; attempt <= limit; attempt++ {
		refreshCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
		lease, err := g.warp.Acquire(refreshCtx)
		if err != nil {
			cancel()
			if ctx.Err() != nil {
				return nil
			}
			continue
		}
		owned, err := g.newWarpLease(lease, false)
		if err != nil {
			lease.Release()
			cancel()
			g.logger.Warn("anonymous model catalog refresh could not use WARP", "component", "models", "event", "anonymous_refresh_failed", "upstream", config.RedactURL(base), "error", err)
			return nil
		}
		egress := "warp:" + lease.EgressKey()
		var listed []string
		var status int
		for _, upstream := range g.anonymousUpstreams() {
			listed, status, err = modelcatalog.FetchModels(refreshCtx, owned.regular, upstream, anonymousZenKey)
			if err == nil || isProxyFailure(err) {
				break
			}
		}
		if status > 0 {
			g.warp.Report(lease, status, nil, 0)
		}
		owned.close()
		cancel()
		if err == nil {
			g.anonymous.NoteSuccess()
			return listed
		}
		g.logger.Debug("anonymous model catalog refresh attempt failed", "component", "models", "event", "anonymous_refresh_attempt_failed", "upstream", config.RedactURL(base), "attempt", attempt, "proxy", egress, "error", err)
	}
	g.logger.Warn("anonymous model catalog refresh failed", "component", "models", "event", "anonymous_refresh_failed", "upstream", config.RedactURL(base))
	return nil
}

// refreshTier lists the models at base with up to retry.max_attempts keys
// from nodes, updating proxy health and key cooldowns after every attempt. It
// returns nil when the pool has no keys or every attempt fails.
func (g *Gateway) refreshTier(ctx context.Context, base string, nodes *upstreamNodes) []string {
	cursor := nodes.Cursor()
	for attempt := 0; attempt < g.cfg.Retry.MaxAttempts; attempt++ {
		node := cursor.Next()
		if node == nil {
			return nil
		}
		refreshCtx, cancel := context.WithTimeout(ctx, 30*time.Second)
		proxy := nodes.Proxy(node)
		if proxy == nil {
			cancel()
			return nil
		}
		models, status, err := modelcatalog.FetchModels(refreshCtx, proxy.client, base, node.key)
		g.syncProxyResult(refreshCtx, proxy, status, err)
		cancel()
		if err == nil {
			nodes.MarkSuccess(node)
			return models
		}
		nodes.MarkFailure(node, nil, err)
		g.logger.Debug("model catalog refresh attempt failed", "component", "models", "event", "refresh_attempt_failed", "upstream", config.RedactURL(base), "attempt", attempt+1, "error", err)
	}
	g.logger.Warn("model catalog refresh failed", "component", "models", "event", "refresh_failed", "upstream", config.RedactURL(base))
	return nil
}
