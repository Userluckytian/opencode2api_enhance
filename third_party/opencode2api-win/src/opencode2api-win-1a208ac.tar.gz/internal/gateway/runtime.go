package gateway

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"net/netip"
	"net/url"
	"os"
	"slices"
	"sync"
	"sync/atomic"
	"time"

	"opencode2api/internal/config"
	modelcatalog "opencode2api/internal/models"
	"opencode2api/internal/oauth"
	"opencode2api/internal/protocol"
	"opencode2api/internal/rotation"
	"opencode2api/internal/telemetry"
	"opencode2api/internal/warp"
)

// warpEgressError marks a runtime that could not be built because its WARP
// egress failed to initialize, so startup can tell that apart from a broken
// configuration and keep serving without WARP.
type warpEgressError struct{ err error }

func (e warpEgressError) Error() string { return "initialize WARP egress: " + e.err.Error() }
func (e warpEgressError) Unwrap() error { return e.err }

// gatewayRuntime is one applied configuration: the Gateway built from it, that
// gateway's HTTP handler, the availability registry it uses, and cancel,
// which stops the gateway's background proxy checks and model refresh.
type gatewayRuntime struct {
	availability *modelcatalog.AvailabilityRegistry
	config       config.Config
	gateway      *Gateway
	handler      http.Handler
	cancel       context.CancelFunc
	// warpPool is the userspace WARP pool this runtime uses, if any. warpKey
	// identifies its size and stack; an unchanged key is reused across
	// configuration reloads. warpCreated marks a pool this build owns and
	// must close if the build is discarded.
	warpPool    *warp.Pool
	warpKey     string
	warpCreated bool
}

// ApplyResult reports whether a configuration was applied and which listener
// fields only take effect after a restart.
type ApplyResult struct {
	Applied         bool     `json:"applied"`
	RestartRequired bool     `json:"restart_required"`
	RestartFields   []string `json:"restart_fields,omitempty"`
}

// warpApplyDeadline caps how long a configuration update waits for the first
// WARP registration. A WebUI save is answered by that same request, so the
// wait must stay short enough to report a failure instead of looking hung.
const warpApplyDeadline = 45 * time.Second

// warpStartupDeadline caps the same wait at startup. Registration alone can
// take over half a minute when Cloudflare rate-limits the client, so this has
// to stay above that or a healthy WARP never survives startup; a broken egress
// still cannot hide the listeners past this point.
const warpStartupDeadline = 90 * time.Second

// RuntimeController owns the running gateway and swaps in a freshly built one
// whenever a configuration is applied; each request is served by the runtime
// that was current when it arrived. It also owns the state that outlives a
// runtime: the persisted rotation manager, the pricing metadata, the
// free-model availability checks and the listeners bound at startup.
type RuntimeController struct {
	rotation           *rotation.Manager
	configPath         string
	root               context.Context
	logger             *slog.Logger
	monitor            *telemetry.Metrics
	hub                *telemetry.LogBroker
	redactor           *config.Redactor
	level              *slog.LevelVar
	current            atomic.Pointer[gatewayRuntime]
	updateMu           sync.Mutex
	oauthMu            sync.Mutex
	oauthClient        *oauth.Client
	goRefresh          *oauthRefresh
	zenRefresh         *oauthRefresh
	effective          EffectiveListeners
	metadata           *modelcatalog.PricingRegistry
	availabilityCancel context.CancelFunc
	// availabilitySweep wakes the probe loop ahead of its minute tick; the
	// capacity-one buffer coalesces requests while a sweep is in flight.
	availabilitySweep chan struct{}
	// warpPool is the pool shared by successive runtimes when the WARP size
	// and stack are unchanged. warpKey is the identity used for that reuse.
	warpPool *warp.Pool
	warpKey  string
	// warpRetryArmed is set while a startup fallback is still trying to bring
	// WARP up in the background. Any applied configuration disarms it: a
	// successful apply either supplied a pool or turned WARP off on purpose.
	warpRetryArmed atomic.Bool
}

// EffectiveListeners are the listener settings the running process actually
// bound at startup. They only change after a restart.
type EffectiveListeners struct {
	API          string
	WebUI        string
	WebUIEnabled bool
}

// RuntimeManager builds the RuntimeController for cfg and starts its first
// runtime. Along the way it migrates a plaintext webui.password to a hash,
// rewriting the config file and deleting the backup that held the plaintext;
// loads the persisted rotation state and the model catalog cache; and starts
// the pricing metadata refresh and the free-model availability checks. It
// fails when the rotation config does not validate against the catalog.
func RuntimeManager(root context.Context, configPath string, cfg config.Config, logger *slog.Logger, monitor *telemetry.Metrics, hub *telemetry.LogBroker, redactor *config.Redactor, level *slog.LevelVar) (*RuntimeController, error) {
	manager := &RuntimeController{
		configPath: configPath, root: root, logger: logger, monitor: monitor, hub: hub, redactor: redactor, level: level,
		effective: EffectiveListeners{API: cfg.Listen, WebUI: cfg.WebUI.Listen, WebUIEnabled: cfg.WebUI.Enabled},
	}
	manager.metadata = modelcatalog.PricingStore(configPath, logger)
	// OpenCode metadata refreshes ride the active runtime's healthy proxy
	// transports and fall back to the registry's direct client when none are
	// available.
	manager.metadata.SetClientProvider(func() []*http.Client {
		runtime := manager.current.Load()
		if runtime == nil || runtime.gateway == nil || runtime.gateway.transports == nil {
			return nil
		}
		clients := make([]*http.Client, 0, len(runtime.gateway.transports.items))
		for _, proxy := range runtime.gateway.transports.items {
			if proxy != nil && proxy.healthy.Load() {
				clients = append(clients, proxy.client)
			}
		}
		return clients
	})
	if cfg.WebUI.Password != "" {
		hash, err := config.HashPassword(cfg.WebUI.Password)
		if err != nil {
			return nil, fmt.Errorf("hash webui password: %w", err)
		}
		cfg.WebUI.PasswordHash = hash
		cfg.WebUI.Password = ""
		if err := config.SaveAtomic(configPath, cfg); err != nil {
			return nil, fmt.Errorf("persist webui password migration: %w", err)
		}
		// The automatically-created backup contains the one-time plaintext
		// bootstrap password and must not be retained.
		_ = os.Remove(configPath + ".bak")
	}
	cfg.Rotation.Defaults()
	rotationManager, err := rotation.New(configPath+".rotation.json", cfg.Rotation)
	if err != nil {
		return nil, err
	}
	manager.rotation = rotationManager
	if cfg.Warp.Enabled && manager.logger != nil {
		// The first WARP registration is synchronous, so the console stays
		// silent until it finishes; say what the wait is for.
		manager.logger.Info("starting; the first WARP registration runs now and gives up after "+warpStartupDeadline.String(), "component", "runtime", "event", "runtime_warp_wait", "warp_startup_deadline", warpStartupDeadline.String())
	}
	runtime, err := manager.build(cfg, warpStartupDeadline)
	var warpErr warpEgressError
	if errors.As(err, &warpErr) {
		// A WARP egress that cannot be reached must not keep the process from
		// starting: without listeners the WebUI cannot even turn WARP off, and
		// every model becomes unreachable. Keep the configured intent on disk,
		// serve everything else, and keep trying in the background: a proxy
		// tunnel or a network that swallows the WireGuard handshake for a
		// minute is temporary, and the operator asked for WARP on disk.
		if manager.logger != nil {
			manager.logger.Warn("WARP egress unavailable; starting without it", "component", "runtime", "event", "warp_startup_fallback", "error", err)
		}
		fallback := cfg
		fallback.Warp.Enabled = false
		runtime, err = manager.build(fallback, 0)
		if err == nil {
			manager.retryWARP(cfg.Warp)
		}
	}
	if err != nil {
		return nil, err
	}
	if err := runtime.gateway.catalog.LoadCache(modelcatalog.CatalogCachePath(configPath)); err != nil && !os.IsNotExist(err) {
		if manager.logger != nil {
			manager.logger.Warn("model catalog cache ignored", "component", "models", "event", "catalog_cache_load_failed", "path", modelcatalog.CatalogCachePath(configPath), "error", err)
		}
	}
	runtime.gateway.restoreOAuthCatalog()
	if err := cfg.Rotation.Validate(runtime.gateway.catalog.List()); err != nil {
		if runtime.warpCreated && runtime.warpPool != nil {
			runtime.warpPool.Close()
		}
		return nil, err
	}
	runtime.gateway.syncRotation()
	manager.current.Store(runtime)
	manager.warpPool, manager.warpKey = runtime.warpPool, runtime.warpKey
	manager.redactor.Replace(cfg)
	telemetry.SetLogLevel(manager.level, cfg.Logging.Level)
	manager.start(runtime)
	manager.metadata.Start(root)
	manager.startAvailabilityChecks()
	return manager, nil
}

// migrateAvailabilityPath moves the legacy 40-bit state file to its 64-bit
// fingerprint path when no file at the new path already exists. A new-format
// file takes precedence.

func migrateAvailabilityPath(legacyPath, currentPath string) error {
	if legacyPath == "" || currentPath == "" || legacyPath == currentPath {
		return nil
	}
	if _, err := os.Stat(currentPath); err == nil {
		return nil
	} else if !os.IsNotExist(err) {
		return err
	}
	if _, err := os.Stat(legacyPath); os.IsNotExist(err) {
		return nil
	} else if err != nil {
		return err
	}
	return os.Rename(legacyPath, currentPath)
}

// build constructs a runtime for cfg without starting it. The runtime shares
// the controller's rotation manager and pricing metadata, and keeps the
// current runtime's availability registry while the Zen upstream is
// unchanged; otherwise it uses the registry persisted for the new upstream.
func (m *RuntimeController) build(cfg config.Config, warpDeadline time.Duration) (*gatewayRuntime, error) {
	warpPool, warpKey, warpCreated, err := m.selectWARP(cfg, warpDeadline)
	if err != nil {
		return nil, err
	}
	discardWARP := func() {
		if warpCreated && warpPool != nil {
			warpPool.Close()
		}
	}
	gateway, err := New(cfg, m.logger, m.monitor, warpPool)
	if err != nil {
		discardWARP()
		return nil, err
	}
	// Install the registration-time quota precheck after New: the check rides
	// the gateway's free-tier request shape, and the pool outlives runtimes, so
	// a shared pool needs it re-installed on every build.
	if warpPool != nil {
		warpPool.SetVerifier(gateway.verifyWARPEgress)
	}
	gateway.rotation = m.rotation
	gateway.onGoOAuthUnauthorized = func(ctx context.Context, credential oauth.Credential) {
		m.invalidateOAuth(ctx, credential)
	}
	gateway.resolveGoOAuth = func(ctx context.Context) (*oauth.Connection, error) {
		connection, err := m.ResolveOAuth(ctx)
		if err != nil {
			return nil, err
		}
		if !slices.Equal(cfg.RuntimeProxies(), m.Config().RuntimeProxies()) {
			return nil, errors.New("Go OAuth proxy configuration changed; retry with the current configuration")
		}
		return connection, nil
	}
	gateway.onZenOAuthUnauthorized = func(ctx context.Context, credential oauth.Credential) {
		m.invalidateOAuth(ctx, credential, config.TierZen)
	}
	gateway.resolveZenOAuth = func(ctx context.Context) (*oauth.Connection, error) {
		connection, err := m.ResolveOAuth(ctx, config.TierZen)
		if err != nil {
			return nil, err
		}
		if !slices.Equal(cfg.RuntimeProxies(), m.Config().RuntimeProxies()) {
			return nil, errors.New("Zen OAuth proxy configuration changed; retry with the current configuration")
		}
		return connection, nil
	}
	availabilityPath := ""
	if m.configPath != "" {
		availabilityPath = m.configPath + "." + config.Fingerprint(cfg.Upstream.Zen) + ".availability.json"
		if err := migrateAvailabilityPath(m.configPath+"."+config.Fingerprint(cfg.Upstream.Zen)[:10]+".availability.json", availabilityPath); err != nil {
			discardWARP()
			return nil, fmt.Errorf("migrate model availability: %w", err)
		}
	}
	availability, err := modelcatalog.AvailabilityStore(availabilityPath)
	if err != nil {
		discardWARP()
		return nil, fmt.Errorf("load model availability: %w", err)
	}
	if current := m.current.Load(); current != nil && current.config.Upstream.Zen == cfg.Upstream.Zen {
		availability = current.availability
	}
	gateway.catalog.SetPricingStore(m.metadata)
	gateway.catalog.SetAvailabilityStore(availability)
	gateway.availability = availability
	gateway.catalog.SetCachePath(modelcatalog.CatalogCachePath(m.configPath))
	return &gatewayRuntime{config: cfg, gateway: gateway, availability: availability, handler: gateway.Handler(), cancel: func() {}, warpPool: warpPool, warpKey: warpKey, warpCreated: warpCreated}, nil
}

// selectWARP returns the WARP pool a runtime built for cfg must use. A pool
// with the same size, stack and outer source prefix is shared across runtimes;
// creating a new one registers its first exit synchronously, so enabling WARP
// fails closed when Cloudflare cannot be reached. A disabled configuration
// returns no pool. A non-zero warpDeadline caps the registration wait, which
// lets an interactive config update fail fast instead of holding its HTTP
// request for a full Cloudflare registration window.
func (m *RuntimeController) selectWARP(cfg config.Config, warpDeadline time.Duration) (*warp.Pool, string, bool, error) {
	if !cfg.Warp.Enabled {
		return nil, "", false, nil
	}
	key := fmt.Sprintf("%d|%s|%s|%t|%s", cfg.Warp.PoolSize, cfg.Warp.Stack, cfg.Warp.SourceIPv6, cfg.Warp.TUN, cfg.Warp.SocksUDP)
	if m.warpPool != nil && m.warpKey == key {
		return m.warpPool, key, false, nil
	}
	var source netip.Prefix
	if cfg.Warp.SourceIPv6 != "" {
		prefix, err := netip.ParsePrefix(cfg.Warp.SourceIPv6)
		if err != nil {
			return nil, "", false, warpEgressError{fmt.Errorf("warp.source_ipv6: %w", err)}
		}
		source = prefix.Masked()
	}
	timeout := time.Duration(cfg.Retry.TimeoutSeconds) * time.Second
	if timeout <= 0 || timeout > 2*time.Minute {
		timeout = 2 * time.Minute
	}
	// The first registration is synchronous: it decides whether the runtime can
	// serve free traffic at all. Cloudflare can answer it with a rate limit even
	// on a fresh process, so give initialization room for one full window
	// instead of failing startup on a pause that is about to end.
	if timeout < warp.RegistrationWindow+30*time.Second {
		timeout = warp.RegistrationWindow + 30*time.Second
	}
	// A WebUI save waits for this build to finish, so cap it: an unreachable
	// Cloudflare must surface as a quick error instead of a button that looks
	// dead for minutes. Startup keeps the full window.
	if warpDeadline > 0 && warpDeadline < timeout {
		timeout = warpDeadline
	}
	ctx, cancel := context.WithTimeout(m.root, timeout)
	defer cancel()
	pool, err := warp.NewWithOptions(ctx, m.logger, warp.Options{Size: cfg.Warp.PoolSize, Stack: warp.Stack(cfg.Warp.Stack), SourceIPv6: source, RegistryProxy: registryProxyURL(cfg), StatePath: warpStatePath(m.configPath), TUN: cfg.Warp.TUN, SocksUDP: cfg.Warp.SocksUDP})
	if err != nil {
		return nil, "", false, warpEgressError{err}
	}
	return pool, key, true, nil
}

// warpStatePath names the file that carries rejected WARP egress blocks across
// restarts, beside the config and its other runtime state files. An empty
// config path disables persistence.
func warpStatePath(configPath string) string {
	if configPath == "" {
		return ""
	}
	return configPath + ".warp-state.json"
}

// registryProxyURL picks the first configured proxy that is not "direct" for
// WARP registration. The data plane cannot use it — WireGuard needs UDP, which
// a CONNECT proxy does not relay — but device creation is plain HTTPS and
// succeeds through the same exit the rest of the gateway already trusts.
func registryProxyURL(cfg config.Config) *url.URL {
	for _, raw := range cfg.RuntimeProxies() {
		clean, _ := config.ParseProxyEntry(raw)
		if clean == "" || clean == "direct" {
			continue
		}
		parsed, err := url.Parse(clean)
		if err != nil || parsed.Scheme == "" || parsed.Host == "" {
			continue
		}
		return parsed
	}
	return nil
}

// warpRetryDelays spaces out the background retries after startup fell back to
// serving without WARP. The first one is short because the usual cause is a
// transient handshake: a proxy tunnel that is still starting, a network that is
// switching nodes, or Cloudflare briefly refusing the registration.
var warpRetryDelays = []time.Duration{
	15 * time.Second,
	30 * time.Second,
	time.Minute,
	2 * time.Minute,
	5 * time.Minute,
}

// retryWARP brings a WARP runtime up in the background after startup fell back
// to serving without it, and swaps it in as soon as one registration succeeds.
// Without this a single unreachable moment at boot leaves the process on direct
// egress until someone restarts it by hand, even though the operator asked for
// WARP. It stops when the controller shuts down, when another runtime already
// supplies a pool, or when the operator turns WARP off in the meantime.
func (m *RuntimeController) retryWARP(want config.WarpConfig) {
	if !want.Enabled {
		return
	}
	m.warpRetryArmed.Store(true)
	go func() {
		for attempt := 0; ; attempt++ {
			delay := warpRetryDelays[len(warpRetryDelays)-1]
			if attempt < len(warpRetryDelays) {
				delay = warpRetryDelays[attempt]
			}
			timer := time.NewTimer(delay)
			select {
			case <-m.root.Done():
				timer.Stop()
				return
			case <-timer.C:
			}
			m.updateMu.Lock()
			current := m.current.Load()
			// A concurrent save or reload may have brought a pool up, and the
			// operator may have turned WARP off while this was waiting.
			if current == nil || current.warpPool != nil || !m.warpRetryArmed.Load() {
				m.updateMu.Unlock()
				return
			}
			candidate := m.Config()
			candidate.Warp = want
			_, err := m.applyLocked(candidate, false)
			m.updateMu.Unlock()
			if err == nil {
				if m.logger != nil {
					m.logger.Info("WARP egress recovered in the background", "component", "runtime", "event", "warp_retry_succeeded", "attempt", attempt+1)
				}
				return
			}
			if m.logger != nil {
				m.logger.Warn("WARP egress still unavailable; will retry", "component", "runtime", "event", "warp_retry_failed", "attempt", attempt+1, "error", err)
			}
		}
	}()
}

// start launches runtime's proxy health checks and model refresh, and stores
// the func that stops them in runtime.cancel.
func (m *RuntimeController) start(runtime *gatewayRuntime) {
	// The loops run under their own context derived from the controller's
	// root, not under any request's: cancel stops catalog refresh and proxy
	// checks while in-flight HTTP requests continue on the old pools.
	runtimeCtx, cancel := context.WithCancel(m.root)
	runtime.cancel = cancel
	runtime.gateway.StartProxyHealthChecks(runtimeCtx)
	runtime.gateway.StartModelRefresh(runtimeCtx)
}

// Handler returns the API handler, wrapped in the telemetry middleware. Each
// request is served by the runtime current when it arrives, so an applied
// configuration reaches new requests without a restart; before the first
// runtime exists the handler answers 503.
func (m *RuntimeController) Handler() http.Handler {
	dynamic := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		runtime := m.current.Load()
		if runtime == nil {
			http.Error(w, "service unavailable", http.StatusServiceUnavailable)
			return
		}
		runtime.handler.ServeHTTP(w, r)
	})
	return telemetry.Middleware(m.monitor, m.logger, dynamic)
}

// Redact removes configured credentials from diagnostic output.
func (m *RuntimeController) Redact(value string) string {
	return m.redactor.String(value)
}

// Config returns a copy of the configuration the current runtime was built
// from, or the zero Config when no runtime exists.
// WarpPool returns the WARP pool of the running runtime, or nil when WARP is
// disabled. A reload that swaps runtimes hands the next call the new pool, so
// the admin blacklist API never edits a retired one.
func (m *RuntimeController) WarpPool() *warp.Pool {
	runtime := m.current.Load()
	if runtime == nil {
		return nil
	}
	return runtime.warpPool
}

func (m *RuntimeController) Config() config.Config {
	runtime := m.current.Load()
	if runtime == nil {
		return config.Config{}
	}
	return config.Clone(runtime.config)
}

// RestartStatus returns the listeners the process bound at startup and the
// config fields (listen, webui.listen, webui.enabled) whose current value
// differs from them, i.e. the changes waiting for a restart.
func (m *RuntimeController) RestartStatus() (EffectiveListeners, []string) {
	cfg := m.Config()
	fields := make([]string, 0, 3)
	if cfg.Listen != m.effective.API {
		fields = append(fields, "listen")
	}
	if cfg.WebUI.Listen != m.effective.WebUI {
		fields = append(fields, "webui.listen")
	}
	if cfg.WebUI.Enabled != m.effective.WebUIEnabled {
		fields = append(fields, "webui.enabled")
	}
	return m.effective, fields
}

// Apply normalizes and validates candidate, builds a runtime from it and
// swaps it in, stopping the previous runtime's background loops. It saves the
// config file when persist is set or candidate carried a plaintext WebUI
// password, which is hashed first.
func (m *RuntimeController) Apply(candidate config.Config, persist bool) (ApplyResult, error) {
	m.updateMu.Lock()
	defer m.updateMu.Unlock()
	return m.applyLocked(candidate, persist)
}

// Update serializes read-modify-write operations against the latest config.
// The changed config is applied and always saved.
func (m *RuntimeController) Update(change func(*config.Config) error) (ApplyResult, error) {
	m.updateMu.Lock()
	defer m.updateMu.Unlock()
	candidate := m.Config()
	if err := change(&candidate); err != nil {
		return ApplyResult{}, err
	}
	return m.applyLocked(candidate, true)
}

// applyLocked does the work of Apply and Update; the caller must hold
// updateMu. Nothing changes until candidate has been normalized, built,
// validated and, when required, saved. The new runtime inherits the current
// catalog state and is started before it is swapped in.
func (m *RuntimeController) applyLocked(candidate config.Config, persist bool) (ApplyResult, error) {

	current := m.current.Load()
	hadPlaintextPassword := candidate.WebUI.Password != ""
	if hadPlaintextPassword {
		hash, err := config.HashPassword(candidate.WebUI.Password)
		if err != nil {
			return ApplyResult{}, err
		}
		candidate.WebUI.PasswordHash = hash
		candidate.WebUI.Password = ""
	}
	normalized, err := config.Normalize(m.configPath, candidate)
	if err != nil {
		return ApplyResult{}, err
	}
	next, err := m.build(normalized, warpApplyDeadline)
	if err != nil {
		return ApplyResult{}, fmt.Errorf("initialize runtime: %w", err)
	}
	if current != nil {
		next.gateway.catalog.CopyState(current.gateway.catalog)
	}
	next.gateway.restoreOAuthCatalog()
	if err := normalized.Rotation.Validate(next.gateway.catalog.List()); err != nil {
		if next.warpCreated && next.warpPool != nil {
			next.warpPool.Close()
		}
		return ApplyResult{}, err
	}
	if persist || hadPlaintextPassword {
		if err := config.SaveAtomic(m.configPath, normalized); err != nil {
			next.cancel()
			if next.warpCreated && next.warpPool != nil {
				next.warpPool.Close()
			}
			return ApplyResult{}, err
		}
	}

	result := ApplyResult{Applied: true}
	if normalized.Listen != m.effective.API {
		result.RestartFields = append(result.RestartFields, "listen")
	}
	if normalized.WebUI.Listen != m.effective.WebUI {
		result.RestartFields = append(result.RestartFields, "webui.listen")
	}
	if normalized.WebUI.Enabled != m.effective.WebUIEnabled {
		result.RestartFields = append(result.RestartFields, "webui.enabled")
	}
	result.RestartRequired = len(result.RestartFields) > 0
	m.redactor.Replace(normalized)
	telemetry.SetLogLevel(m.level, normalized.Logging.Level)
	if current == nil || normalized.Logging.RingSize != current.config.Logging.RingSize {
		m.hub.Resize(normalized.Logging.RingSize)
	}
	m.rotation.Configure(normalized.Rotation)
	next.gateway.syncRotation()
	m.start(next)
	previous := m.current.Swap(next)
	m.warpPool, m.warpKey = next.warpPool, next.warpKey
	// A successful apply either supplied a WARP pool itself or was asked for a
	// configuration without WARP, so a pending background retry is moot.
	m.warpRetryArmed.Store(false)
	if previous != nil {
		previous.cancel()
		if previous.warpPool != nil && previous.warpPool != next.warpPool {
			// Requests that loaded the previous runtime may still acquire a
			// lease. Close the old pool only after the longest request budget
			// has passed; leases already held keep their exits alive.
			grace := time.Duration(normalized.Retry.TimeoutSeconds) * time.Second
			if grace <= 0 || grace > 5*time.Minute {
				grace = 5 * time.Minute
			}
			retired := previous.warpPool
			time.AfterFunc(grace, retired.Close)
		}
	}
	m.logger.Info("configuration applied", "component", "config", "event", "config_applied", "restart_required", result.RestartRequired, "restart_fields", result.RestartFields)
	return result, nil
}

// Reload re-reads the config file and applies it without rewriting it, unless
// it holds a plaintext WebUI password: that is hashed and saved, and the
// backup holding the plaintext is removed.
func (m *RuntimeController) Reload() (ApplyResult, error) {
	m.updateMu.Lock()
	defer m.updateMu.Unlock()
	cfg, err := config.Load(m.configPath)
	if err != nil {
		return ApplyResult{}, err
	}
	hadPlaintextPassword := cfg.WebUI.Password != ""
	result, err := m.applyLocked(cfg, false)
	if err == nil && hadPlaintextPassword {
		_ = os.Remove(m.configPath + ".bak")
	}
	return result, err
}

// Shutdown stops the free-model availability checks and the current runtime's
// background loops.
func (m *RuntimeController) Shutdown() {
	if m.availabilityCancel != nil {
		m.availabilityCancel()
	}
	if current := m.current.Load(); current != nil {
		current.cancel()
	}
	if m.warpPool != nil {
		m.warpPool.Close()
		m.warpPool = nil
		m.warpKey = ""
	}
}

// ResourceSnapshot is the operator view of the current runtime's models, keys,
// proxies and model metadata (see Resources).
type ResourceSnapshot struct {
	Models    modelcatalog.CatalogSnapshot  `json:"models"`
	Keys      []KeyStatus                   `json:"keys"`
	Proxies   []ProxyStatus                 `json:"proxies"`
	Anonymous bool                          `json:"anonymous"`
	Warp      *WarpStatus                   `json:"warp,omitempty"`
	Metadata  modelcatalog.MetadataSnapshot `json:"metadata"`
}

// WarpStatus is the operator view of the WARP egress pool.
type WarpStatus struct {
	Enabled bool     `json:"enabled"`
	Stack   string   `json:"stack"`
	Size    int      `json:"size"`
	Active  int      `json:"active"`
	Standby int      `json:"standby"`
	Cooling int      `json:"cooling"`
	Egress  []string `json:"egress,omitempty"`
}

// KeyStatus describes one upstream key by its display ID (its last five
// characters): its tier, its current proxy binding, its consecutive failures
// and any active cooldown.
type KeyStatus struct {
	ID            string     `json:"id"`
	Tier          string     `json:"tier"`
	Index         int        `json:"index"`
	ProxyIndex    int        `json:"proxy_index"`
	Bound         bool       `json:"bound,omitempty"`
	Failures      uint32     `json:"failures"`
	CooldownUntil *time.Time `json:"cooldown_until,omitempty"`
}

// ProxyStatus describes one proxy route: its redacted address, its health,
// whether a health check is in flight, and how many Zen and Go keys are bound
// to it. Anonymous reports whether the anonymous lane, which uses every
// proxy, is enabled.
type ProxyStatus struct {
	Index     int    `json:"index"`
	Address   string `json:"address"`
	Healthy   bool   `json:"healthy"`
	Checking  bool   `json:"checking"`
	ZenKeys   int    `json:"zen_keys"`
	GoKeys    int    `json:"go_keys"`
	Anonymous bool   `json:"anonymous"`
}

// Resources reports the current runtime's servable models, per-key state and
// per-proxy health and key bindings, or an empty snapshot when no runtime
// exists.
func (m *RuntimeController) Resources() ResourceSnapshot {
	runtime := m.current.Load()
	if runtime == nil {
		return ResourceSnapshot{}
	}
	gateway := runtime.gateway
	_, models := gateway.availableModels()
	result := ResourceSnapshot{Models: models, Anonymous: gateway.cfg.Anonymous}
	result.Metadata = gateway.catalog.MetadataSnapshot()
	result.Keys = append(result.Keys, keyStatuses("zen", gateway.zenNodes)...)
	if connection := gateway.cfg.GoOAuth; connection != nil {
		status := KeyStatus{ID: oauthAccountID(connection), Tier: string(config.TierGo), ProxyIndex: -1, Bound: connection.Proxy != ""}
		for _, proxy := range gateway.transports.items {
			if connection.Proxy != "" && proxy.name == connection.Proxy {
				status.ProxyIndex = proxy.index
				break
			}
		}
		result.Keys = append(result.Keys, status)
	} else {
		result.Keys = append(result.Keys, keyStatuses("go", gateway.goNodes)...)
	}
	if connection := gateway.cfg.ZenOAuth; connection != nil {
		status := KeyStatus{ID: oauthAccountID(connection), Tier: string(config.TierZen), ProxyIndex: -1, Bound: connection.Proxy != ""}
		for _, proxy := range gateway.transports.items {
			if connection.Proxy != "" && proxy.name == connection.Proxy {
				status.ProxyIndex = proxy.index
				break
			}
		}
		result.Keys = append(result.Keys, status)
	}
	gateway.zenNodes.bindingsMu.Lock()
	zenBindings := append([]int(nil), gateway.zenNodes.bindingCount...)
	gateway.zenNodes.bindingsMu.Unlock()
	gateway.goNodes.bindingsMu.Lock()
	goBindings := append([]int(nil), gateway.goNodes.bindingCount...)
	gateway.goNodes.bindingsMu.Unlock()
	for _, proxy := range gateway.transports.items {
		status := ProxyStatus{Index: proxy.index, Address: config.RedactURL(proxy.name), Healthy: proxy.healthy.Load(), Checking: proxy.checking.Load(), Anonymous: gateway.cfg.Anonymous}
		if proxy.index < len(zenBindings) {
			status.ZenKeys = zenBindings[proxy.index]
		}
		if proxy.index < len(goBindings) {
			status.GoKeys = goBindings[proxy.index]
		}
		if gateway.cfg.GoOAuth != nil && gateway.cfg.GoOAuth.Proxy == proxy.name {
			status.GoKeys = 1
		}
		if gateway.cfg.ZenOAuth != nil && gateway.cfg.ZenOAuth.Proxy == proxy.name {
			status.ZenKeys = 1
		}
		result.Proxies = append(result.Proxies, status)
	}
	if gateway.warp != nil {
		snapshot := gateway.warp.Snapshot()
		result.Warp = &WarpStatus{
			Enabled: true, Stack: snapshot.Stack, Size: snapshot.Size,
			Active: snapshot.Active, Standby: snapshot.Standby, Cooling: snapshot.Cooling,
			Egress: snapshot.Egress,
		}
	}
	return result
}

// DebugModels returns a routing diagnostic for every catalog model, with no
// requested protocol, plus the catalog's metadata snapshot.
func (m *RuntimeController) DebugModels() ([]modelcatalog.RouteDiagnostic, modelcatalog.MetadataSnapshot) {
	runtime := m.current.Load()
	if runtime == nil {
		return nil, modelcatalog.MetadataSnapshot{}
	}
	gateway := runtime.gateway
	models := gateway.catalog.List()
	result := make([]modelcatalog.RouteDiagnostic, 0, len(models))
	for _, model := range models {
		result = append(result, gateway.routeDiagnostic(model, ""))
	}
	metadata := gateway.catalog.MetadataSnapshot()
	return result, metadata
}

// DebugRoute reports how the current runtime would route a request for model
// sent on the requested protocol.
func (m *RuntimeController) DebugRoute(model string, requested protocol.Protocol) modelcatalog.RouteDiagnostic {
	runtime := m.current.Load()
	if runtime == nil {
		return modelcatalog.RouteDiagnostic{Model: model, RequestedProtocol: requested, RouteError: "gateway runtime is unavailable"}
	}
	gateway := runtime.gateway
	return gateway.routeDiagnostic(model, requested)
}

// DebugKeyView is the operator-facing view of one configured upstream key. It
// carries only the redacted suffix and the stable fingerprint, never the value.
type DebugKeyView struct {
	ID            string      `json:"id"`
	Tier          config.Tier `json:"tier"`
	Display       string      `json:"display"`
	Index         int         `json:"index"`
	Failures      uint32      `json:"failures"`
	CooldownUntil *time.Time  `json:"cooldown_until,omitempty"`
}

// DebugRelays lists the anonymous relays in pool order for the Playground.
func (m *RuntimeController) DebugRelays() []string {
	rt := m.current.Load()
	if rt == nil || rt.gateway == nil {
		return nil
	}
	return rt.gateway.RelayNames()
}

// DebugKeys lists every configured upstream key per tier so the Playground can
// offer an explicit per-key test target.
func (m *RuntimeController) DebugKeys() map[string][]DebugKeyView {
	result := map[string][]DebugKeyView{"zen": {}, "go": {}}
	runtime := m.current.Load()
	if runtime == nil {
		return result
	}
	appendKeys := func(tier config.Tier, nodes []*upstreamNode) {
		for _, node := range nodes {
			view := DebugKeyView{
				ID: config.Fingerprint(node.key), Tier: tier, Display: config.MaskValue(node.key),
				Index: node.index, Failures: node.failures.Load(),
			}
			if until := node.cooldownUntil.Load(); until > time.Now().UnixNano() {
				value := time.Unix(0, until).UTC()
				view.CooldownUntil = &value
			}
			result[string(tier)] = append(result[string(tier)], view)
		}
	}
	if connection := runtime.config.ZenOAuth; connection != nil {
		result["zen"] = append(result["zen"], DebugKeyView{ID: oauthAccountID(connection), Tier: config.TierZen, Display: "Zen PAYG (OAuth)"})
	} else {
		appendKeys(config.TierZen, runtime.gateway.zenNodes.nodes)
	}
	if connection := runtime.config.GoOAuth; connection != nil {
		result["go"] = append(result["go"], DebugKeyView{ID: oauthAccountID(connection), Tier: config.TierGo, Display: "Go OAuth"})
	} else {
		appendKeys(config.TierGo, runtime.gateway.goNodes.nodes)
	}
	return result
}

// DebugKey returns the view of the tier's key whose fingerprint is id, or nil
// when no such key is configured.
func (m *RuntimeController) DebugKey(tier config.Tier, id string) *DebugKeyView {
	for _, view := range m.DebugKeys()[string(tier)] {
		if view.ID == id {
			selected := view
			return &selected
		}
	}
	return nil
}

// DebugRouteForTier reports the route a diagnostic against one tier would take.
func (m *RuntimeController) DebugRouteForTier(model string, tier config.Tier) (modelcatalog.RouteDiagnostic, error) {
	runtime := m.current.Load()
	if runtime == nil {
		return modelcatalog.RouteDiagnostic{Model: model, RouteError: "gateway runtime is unavailable"}, fmt.Errorf("gateway runtime is unavailable")
	}
	gateway := runtime.gateway
	diagnostic := gateway.routeDiagnostic(model, "")
	route, err := gateway.routeForModel(model, tier)
	if err != nil {
		diagnostic.RouteError = err.Error()
		return diagnostic, err
	}
	diagnostic.RouteError = ""
	diagnostic.Tier, diagnostic.Anonymous = route.Tier, false
	diagnostic.KeyTiers = []config.Tier{tier}
	diagnostic.NativeProtocol, diagnostic.NativeProtocols = route.Protocol, route.Protocols
	if connection := gateway.tierOAuth(tier); connection != nil {
		diagnostic.ProtocolSource = string(tier) + "_oauth"
		diagnostic.Channel, diagnostic.KeyID = "oauth", oauthAccountID(connection)
	} else {
		diagnostic.Channel, diagnostic.KeyID = "", ""
		if diagnostic.ProtocolSource == "go_oauth" || diagnostic.ProtocolSource == "zen_oauth" {
			diagnostic.ProtocolSource = "upstream"
		}
	}
	return diagnostic, nil
}

func keyStatuses(tier string, pool *upstreamNodes) []KeyStatus {
	result := make([]KeyStatus, 0, len(pool.nodes))
	for _, node := range pool.nodes {
		status := KeyStatus{ID: config.KeyDisplayID(node.key), Tier: tier, Index: node.index, ProxyIndex: int(node.proxyIndex.Load()), Bound: node.bound, Failures: node.failures.Load()}
		if until := node.cooldownUntil.Load(); until > time.Now().UnixNano() {
			value := time.Unix(0, until).UTC()
			status.CooldownUntil = &value
		}
		result = append(result, status)
	}
	return result
}
